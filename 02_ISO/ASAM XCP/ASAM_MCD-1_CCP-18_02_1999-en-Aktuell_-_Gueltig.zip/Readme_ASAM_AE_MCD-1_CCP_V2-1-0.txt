/************************************************************** 
*** ASAM AE_MCD-1_CCP                                       *** 
*** Version :  2.1                                          ***
*** Date:      2013/06/20                                   *** 
***************************************************************/

The deliverable of ASAM AE MCD-1 CCP Version 2.1.0 includes:

Directory Documents: 
    Base Standard:
    - ASAM_AE_MCD-1_CCP_BS_V2-1-0.pdf
	
Directory CCP-AML:
    - ccp_v2_6.aml
